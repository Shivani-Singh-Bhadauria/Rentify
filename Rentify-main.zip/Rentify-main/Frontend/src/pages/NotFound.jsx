import React from 'react'

function NotFound() {
  return (
    <div>
      Page NotFound
    </div>
  )
}

export default NotFound
